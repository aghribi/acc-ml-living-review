---
title: "About"
---

This site hosts the **Accelerator ML Living Review**, a continuously updated overview of AI and machine learning applications in particle accelerator physics.
